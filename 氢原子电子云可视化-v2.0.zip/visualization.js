// 3D 可视化效果模块
window.ElectronCloud = window.ElectronCloud || {};
window.ElectronCloud.Visualization = {};

// 创建角向分布3D可视化
window.ElectronCloud.Visualization.createAngularOverlay = function () {
    const state = window.ElectronCloud.state;

    const overlayGroup = new THREE.Group();

    // 检查是否有选中的轨道
    if (!state.currentOrbitals || state.currentOrbitals.length === 0) return overlayGroup;

    // 【优化】角向显示大小设置为轨道轮廓（95%分位半径）的91%（原130%的70%）
    // 先计算95%分位半径
    let contourRadius = Math.max(15, state.farthestDistance * 0.6);
    if (window.ElectronCloud.Visualization.calculate95PercentileRadius) {
        const r95 = window.ElectronCloud.Visualization.calculate95PercentileRadius();
        if (r95 > 0) {
            contourRadius = r95;
        }
    }
    const baseRadius = contourRadius * 0.91; // 91% of contour (70% of original 130%)

    window.ElectronCloud.Visualization.createOrbitalMesh(overlayGroup, null, baseRadius);

    return overlayGroup;
};

/**
 * 创建轨道网格表面
 * 
 * 【关键】网格极点对准轨道的最高次旋转对称轴
 */
window.ElectronCloud.Visualization.createOrbitalMesh = function (group, params, baseRadius) {
    const state = window.ElectronCloud.state;
    const isHybridMode = state.isHybridMode === true;
    const isSingleHybridMode = isHybridMode && state.hybridRenderMode === 'single';
    const hybridIndex = state.hybridSingleIndex || 0;

    // 获取所有轨道参数
    let orbitalParams = state.currentOrbitals.map(key => Hydrogen.orbitalParamsFromKey(key)).filter(Boolean);
    // 【关键修复】对轨道进行排序，确保与 getHybridCoefficients 假设的顺序一致
    if (isHybridMode && Hydrogen.sortOrbitalsForHybridization) {
        orbitalParams = Hydrogen.sortOrbitalsForHybridization(orbitalParams);
    }
    const numOrbitals = orbitalParams.length;

    // 获取杂化系数矩阵（如果是杂化模式）
    let coeffMatrix = null;
    if (isHybridMode && numOrbitals > 1 && Hydrogen.getHybridCoefficients) {
        coeffMatrix = Hydrogen.getHybridCoefficients(numOrbitals);
    }

    // 【关键】确定网格极点的目标方向（最高次对称轴）
    let symmetryAxis = { x: 0, y: 0, z: 1 };

    console.log('[DEBUG createOrbitalMesh] isHybridMode:', isHybridMode, 'isSingleHybridMode:', isSingleHybridMode, 'hybridIndex:', hybridIndex);

    if (isSingleHybridMode) {
        // 单个杂化轨道模式：使用解析算法计算当前 Lobe 的指向
        if (Hydrogen.getHybridLobeAxis) {
            symmetryAxis = Hydrogen.getHybridLobeAxis(orbitalParams, hybridIndex);
        } else if (Hydrogen.findHybridPrincipalAxis) {
            symmetryAxis = Hydrogen.findHybridPrincipalAxis(orbitalParams, hybridIndex);
        }
    } else if (isHybridMode && numOrbitals > 1) {
        // 全部杂化轨道模式：使用群论/成分分析计算对称轴
        if (Hydrogen.getSetSymmetryAxis) {
            symmetryAxis = Hydrogen.getSetSymmetryAxis(orbitalParams);
        } else if (Hydrogen.findHybridPrincipalAxis) {
            symmetryAxis = Hydrogen.findHybridPrincipalAxis(orbitalParams, 0);
        }
    } else if (!isHybridMode && numOrbitals === 1 && Hydrogen.getOrbitalSymmetryAxis) {
        // 单个原子轨道模式
        symmetryAxis = Hydrogen.getOrbitalSymmetryAxis(orbitalParams[0].angKey);
    }

    // 【关键】THREE.js SphereGeometry 极点在 Y 轴，需要旋转到对称轴方向
    let quaternion = null;
    const threeJsPoleAxis = new THREE.Vector3(0, 1, 0);
    const targetAxis = new THREE.Vector3(symmetryAxis.x, symmetryAxis.y, symmetryAxis.z).normalize();

    const dotProduct = threeJsPoleAxis.dot(targetAxis);
    if (Math.abs(dotProduct - 1) > 1e-6) {
        quaternion = new THREE.Quaternion();
        quaternion.setFromUnitVectors(threeJsPoleAxis, targetAxis);
    }

    // 角向强度计算函数（在物理坐标系中计算）
    function calcAngularIntensity(theta, phi) {
        if (isSingleHybridMode && coeffMatrix) {
            const coeffs = coeffMatrix[hybridIndex % numOrbitals];
            let psiSum = 0;
            for (let i = 0; i < numOrbitals; i++) {
                const op = orbitalParams[i];
                const Y = Hydrogen.realYlm_value(op.angKey.l, op.angKey.m, op.angKey.t, theta, phi);
                psiSum += coeffs[i] * Y;
            }
            return psiSum * psiSum; // |Ψ|²
        } else if (isHybridMode && numOrbitals > 1 && coeffMatrix) {
            let totalIntensity = 0;
            for (let h = 0; h < numOrbitals; h++) {
                const coeffs = coeffMatrix[h];
                let psiSum = 0;
                for (let i = 0; i < numOrbitals; i++) {
                    const op = orbitalParams[i];
                    const Y = Hydrogen.realYlm_value(op.angKey.l, op.angKey.m, op.angKey.t, theta, phi);
                    psiSum += coeffs[i] * Y;
                }
                totalIntensity += psiSum * psiSum;
            }
            return totalIntensity;
        } else {
            let intensity = 0;
            for (const op of orbitalParams) {
                const Y = Hydrogen.realYlm_value(op.angKey.l, op.angKey.m, op.angKey.t, theta, phi);
                intensity += Y * Y;
            }
            return intensity;
        }
    }

    // 提高网格密度 - 使用 IcosahedronGeometry (Icosphere) 替代 SphereGeometry
    // detail=50 (约 156,060 顶点) for ultra high density mesh
    const geometry = new THREE.IcosahedronGeometry(baseRadius, 50);
    const vertices = geometry.attributes.position.array;
    const colors = new Float32Array(vertices.length);

    for (let i = 0; i < vertices.length; i += 3) {
        const x0 = vertices[i];
        const y0 = vertices[i + 1];
        const z0 = vertices[i + 2];

        const r0 = Math.sqrt(x0 * x0 + y0 * y0 + z0 * z0);
        if (r0 < 1e-10) continue;

        // 将顶点方向旋转到物理坐标系
        let physDir = new THREE.Vector3(x0 / r0, y0 / r0, z0 / r0);
        if (quaternion) {
            physDir.applyQuaternion(quaternion);
        }

        const theta = Math.acos(Math.max(-1, Math.min(1, physDir.z)));
        const phi = Math.atan2(physDir.y, physDir.x);

        const totalAngularIntensity = calcAngularIntensity(theta, phi);

        const radiusScale = 1 + Math.sqrt(totalAngularIntensity) * 1.5;
        const newR = r0 * radiusScale;

        vertices[i] = physDir.x * newR;
        vertices[i + 1] = physDir.y * newR;
        vertices[i + 2] = physDir.z * newR;

        const intensity = Math.min(totalAngularIntensity * 3, 1);
        colors[i] = intensity;
        colors[i + 1] = intensity;
        colors[i + 2] = intensity;
    }

    geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    geometry.attributes.position.needsUpdate = true;

    const material = new THREE.MeshBasicMaterial({
        vertexColors: true,
        transparent: true,
        opacity: 0.7,
        side: THREE.DoubleSide,
        wireframe: true,
        wireframeLinewidth: 2,
        depthWrite: false,
        blending: THREE.AdditiveBlending
    });

    const mesh = new THREE.Mesh(geometry, material);
    mesh.layers.set(1);
    group.add(mesh);
};

// 更新角向分布叠加
window.ElectronCloud.Visualization.updateAngularOverlay = function () {
    const state = window.ElectronCloud.state;
    const ui = window.ElectronCloud.ui;

    if (!ui.angular3dToggle || !ui.angular3dToggle.checked) return;

    if (state.angularOverlay) {
        state.scene.remove(state.angularOverlay);
        state.angularOverlay.traverse((child) => {
            if (child.geometry) child.geometry.dispose();
            if (child.material) child.material.dispose();
        });
    }

    state.angularOverlay = window.ElectronCloud.Visualization.createAngularOverlay();
    state.angularOverlay.visible = true;

    if (state.points) {
        state.angularOverlay.rotation.copy(state.points.rotation);
        state.angularOverlay.updateMatrix();
    }

    state.scene.add(state.angularOverlay);
};

// 基于实际采样数据更新角向分布
window.ElectronCloud.Visualization.updateAngularOverlayFromSamples = function () {
    const state = window.ElectronCloud.state;
    const ui = window.ElectronCloud.ui;

    if (!ui.angular3dToggle || !ui.angular3dToggle.checked || !state.angularSamples || state.angularSamples.length === 0) return;

    if (state.angularOverlay) {
        state.scene.remove(state.angularOverlay);
        state.angularOverlay.traverse((child) => {
            if (child.geometry) child.geometry.dispose();
            if (child.material) child.material.dispose();
        });
    }

    state.angularOverlay = window.ElectronCloud.Visualization.createAngularOverlayFromSamples();
    state.angularOverlay.visible = true;

    if (state.points) {
        state.angularOverlay.rotation.copy(state.points.rotation);
        state.angularOverlay.updateMatrix();
    }

    state.scene.add(state.angularOverlay);
};

// 基于采样数据创建角向分布
window.ElectronCloud.Visualization.createAngularOverlayFromSamples = function () {
    const state = window.ElectronCloud.state;

    const overlayGroup = new THREE.Group();

    if (!state.angularSamples || state.angularSamples.length === 0) {
        return window.ElectronCloud.Visualization.createAngularOverlay();
    }

    const baseRadius = Math.max(15, state.farthestDistance * 0.6);
    const thetaBins = 64;
    const phiBins = 128;

    const densityMap = new Array(thetaBins).fill(0).map(() => new Array(phiBins).fill(0));

    for (let i = 0; i < state.pointCount && i < state.radialSamples.length; i++) {
        const theta = state.angularSamples[i];

        if (state.points && state.points.geometry) {
            const positions = state.points.geometry.attributes.position.array;
            const x = positions[i * 3];
            const y = positions[i * 3 + 1];
            // const z = positions[i * 3 + 2]; 
            const phi = Math.atan2(y, x);

            const thetaIndex = Math.floor((theta / Math.PI) * (thetaBins - 1));
            const phiIndex = Math.floor(((phi + Math.PI) / (2 * Math.PI)) * (phiBins - 1));

            if (thetaIndex >= 0 && thetaIndex < thetaBins && phiIndex >= 0 && phiIndex < phiBins) {
                densityMap[thetaIndex][phiIndex]++;
            }
        }
    }

    let maxDensity = 0;
    for (let i = 0; i < thetaBins; i++) {
        for (let j = 0; j < phiBins; j++) {
            maxDensity = Math.max(maxDensity, densityMap[i][j]);
        }
    }

    if (maxDensity === 0) {
        return window.ElectronCloud.Visualization.createAngularOverlay();
    }

    // 使用 IcosahedronGeometry 替代 SphereGeometry，确保所有模式下网格密度一致且无极点
    // detail=50 (约 156,060 顶点)
    const geometry = new THREE.IcosahedronGeometry(baseRadius, 50);
    const vertices = geometry.attributes.position.array;
    const colors = new Float32Array(vertices.length);

    for (let i = 0; i < vertices.length; i += 3) {
        const x = vertices[i];
        const y = vertices[i + 1];
        const z = vertices[i + 2];

        const r = Math.sqrt(x * x + y * y + z * z);
        const theta = Math.acos(z / r);
        const phi = Math.atan2(y, x);

        const thetaIndex = Math.floor((theta / Math.PI) * (thetaBins - 1));
        const phiIndex = Math.floor(((phi + Math.PI) / (2 * Math.PI)) * (phiBins - 1));

        let density = 0;
        if (thetaIndex >= 0 && thetaIndex < thetaBins && phiIndex >= 0 && phiIndex < phiBins) {
            density = densityMap[thetaIndex][phiIndex] / maxDensity;
        }

        const radiusScale = 1 + density * 2;
        vertices[i] = x * radiusScale;
        vertices[i + 1] = y * radiusScale;
        vertices[i + 2] = z * radiusScale;

        const intensityColor = Math.min(density * 1.2, 1);
        colors[i] = intensityColor;
        colors[i + 1] = intensityColor;
        colors[i + 2] = intensityColor;
    }

    geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    geometry.attributes.position.needsUpdate = true;

    const material = new THREE.MeshBasicMaterial({
        vertexColors: true,
        transparent: true,
        opacity: 0.75,
        side: THREE.DoubleSide,
        wireframe: true,
        wireframeLinewidth: 2
    });

    const mesh = new THREE.Mesh(geometry, material);
    mesh.layers.set(1);
    overlayGroup.add(mesh);

    return overlayGroup;
};

// 导出截图
window.ElectronCloud.Visualization.exportImage = function () {
    console.log('exportImage 函数被调用');
    const state = window.ElectronCloud.state;

    if (!state || !state.renderer) {
        alert('导出失败: 渲染器未初始化');
        return;
    }

    const backgroundSelect = document.getElementById('export-background-select');
    const background = backgroundSelect ? backgroundSelect.value : 'black';
    const canvas = state.renderer.domElement;

    try {
        if (background === 'transparent') {
            const tempCanvas = document.createElement('canvas');
            tempCanvas.width = canvas.width;
            tempCanvas.height = canvas.height;
            const ctx = tempCanvas.getContext('2d');
            ctx.drawImage(canvas, 0, 0);
            const imageData = ctx.getImageData(0, 0, tempCanvas.width, tempCanvas.height);
            const data = imageData.data;
            for (let i = 0; i < data.length; i += 4) {
                const r = data[i];
                const g = data[i + 1];
                const b = data[i + 2];
                const luminance = 0.299 * r + 0.587 * g + 0.114 * b;
                const maxChannel = Math.max(r, g, b);
                let alpha = Math.max(luminance, maxChannel);
                alpha = Math.min(255, alpha * 1.2);
                data[i + 3] = Math.round(alpha);
            }
            ctx.putImageData(imageData, 0, 0);
            tempCanvas.toBlob(function (blob) {
                if (!blob) return;
                const url = URL.createObjectURL(blob);
                const link = document.createElement('a');
                const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
                link.download = `electron-cloud-${canvas.width}x${canvas.height}-transparent-${timestamp}.png`;
                link.href = url;
                document.body.appendChild(link);
                link.click();
                setTimeout(() => { document.body.removeChild(link); URL.revokeObjectURL(url); }, 100);
            }, 'image/png');
        } else {
            const tempCanvas = document.createElement('canvas');
            tempCanvas.width = canvas.width;
            tempCanvas.height = canvas.height;
            const ctx = tempCanvas.getContext('2d');
            ctx.fillStyle = '#000000';
            ctx.fillRect(0, 0, tempCanvas.width, tempCanvas.height);
            ctx.drawImage(canvas, 0, 0);
            tempCanvas.toBlob(function (blob) {
                if (!blob) return;
                const url = URL.createObjectURL(blob);
                const link = document.createElement('a');
                const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
                link.download = `electron-cloud-${canvas.width}x${canvas.height}-black-${timestamp}.png`;
                link.href = url;
                document.body.appendChild(link);
                link.click();
                setTimeout(() => { document.body.removeChild(link); URL.revokeObjectURL(url); }, 100);
            }, 'image/png');
        }
    } catch (err) {
        console.error('导出截图失败:', err);
    }
};

// ==================== 95% 等值面轮廓（点云高亮方案）====================
// 【新方案】不使用网格，而是高亮现有采样点中靠近等值面的点
// 优势：天然解决波瓣分离问题，每个点独立，不会粘连

/**
 * 启用等值面轮廓高亮
 * 高亮现有点云中位于等值面附近的点
 */
window.ElectronCloud.Visualization.enableContourHighlight = function () {
    const state = window.ElectronCloud.state;
    const ui = window.ElectronCloud.ui;

    if (!state.points || state.pointCount < 100) {
        console.log('[Contour] 点数不足，无法显示等值面');
        return;
    }

    console.log('[Contour] 启用等值面高亮，点数:', state.pointCount);

    // 标记等值面高亮已启用
    state.contourHighlightEnabled = true;

    // 计算每个点的密度排名（如果wave模式没有预先计算）
    const Hydrogen = window.Hydrogen;
    const positions = state.points.geometry.attributes.position;
    const colors = state.points.geometry.attributes.color;
    const pointCount = state.pointCount;
    const maxPoints = state.MAX_POINTS || 100000;

    // 获取轨道参数
    const isHybridMode = state.isHybridMode === true;
    const orbitals = state.currentOrbitals || [state.currentOrbital || '1s'];
    let orbitalParams = orbitals.map(key => Hydrogen.orbitalParamsFromKey(key)).filter(Boolean);

    if (isHybridMode && Hydrogen.sortOrbitalsForHybridization) {
        orbitalParams = Hydrogen.sortOrbitalsForHybridization(orbitalParams);
    }

    if (orbitalParams.length === 0) {
        console.log('[Contour] 没有有效的轨道参数');
        return;
    }

    // 初始化等值面相关数组
    if (!state.contourRanks || state.contourRanks.length < maxPoints) {
        state.contourRanks = new Float32Array(maxPoints);
        state.contourDensities = new Float32Array(maxPoints);
        state.contourPsiSigns = new Int8Array(maxPoints); // 存储波函数符号
    }

    // 保存原始颜色（用于恢复）
    if (!state.contourBaseColors || state.contourBaseColors.length < maxPoints * 3) {
        state.contourBaseColors = new Float32Array(maxPoints * 3);
    }
    const colorArray = colors.array;
    for (let i = 0; i < pointCount * 3; i++) {
        state.contourBaseColors[i] = colorArray[i];
    }

    // 获取杂化系数矩阵
    let coeffMatrix = null;
    if (isHybridMode && Hydrogen.getHybridCoefficients && orbitalParams.length > 1) {
        coeffMatrix = Hydrogen.getHybridCoefficients(orbitalParams.length);
    }

    // 是否为比照模式
    const isCompareMode = ui.compareToggle && ui.compareToggle.checked;
    const usePerPointOrbital = (isCompareMode || isHybridMode) && state.pointOrbitalIndices;

    console.log('[Contour] 开始计算密度和相位...');

    // 计算每个点的密度和波函数符号（相位）
    for (let i = 0; i < pointCount; i++) {
        const i3 = i * 3;
        const x = positions.array[i3];
        const y = positions.array[i3 + 1];
        const z = positions.array[i3 + 2];
        const r = Math.sqrt(x * x + y * y + z * z);
        const theta = r > 0 ? Math.acos(Math.max(-1, Math.min(1, z / r))) : 0;
        const phi = Math.atan2(y, x);

        let density = 0;
        let psi = 0;

        if (isHybridMode && coeffMatrix && usePerPointOrbital) {
            // 杂化模式：使用该点所属的杂化轨道
            const hybridIdx = state.pointOrbitalIndices[i] || 0;
            const coeffs = coeffMatrix[hybridIdx] || coeffMatrix[0];

            for (let j = 0; j < orbitalParams.length; j++) {
                const op = orbitalParams[j];
                const R = Hydrogen.radialWavefunction(op.n, op.l, r);
                const Y = Hydrogen.realYlm_value(op.angKey.l, op.angKey.m, op.angKey.t, theta, phi);
                psi += coeffs[j] * R * Y;
            }
            density = psi * psi;
        } else if (isCompareMode && usePerPointOrbital) {
            // 比照模式：使用该点所属的轨道
            const orbitalIndex = state.pointOrbitalIndices[i] || 0;
            const op = orbitalParams[orbitalIndex] || orbitalParams[0];
            const R = Hydrogen.radialWavefunction(op.n, op.l, r);
            const Y = Hydrogen.realYlm_value(op.angKey.l, op.angKey.m, op.angKey.t, theta, phi);
            psi = R * Y;
            density = psi * psi;
        } else {
            // 单选或多选叠加模式
            for (const op of orbitalParams) {
                const R = Hydrogen.radialWavefunction(op.n, op.l, r);
                const Y = Hydrogen.realYlm_value(op.angKey.l, op.angKey.m, op.angKey.t, theta, phi);
                psi += R * Y;
            }
            density = psi * psi;
        }

        state.contourDensities[i] = density;
        state.contourPsiSigns[i] = psi > 0 ? 1 : (psi < 0 ? -1 : 0);
    }

    // 按密度排序，计算每个点的等值面排名
    // 对于比照模式和杂化模式，按轨道分组排序
    if (usePerPointOrbital) {
        // 按轨道分组
        const orbitalPointGroups = {};
        for (let i = 0; i < pointCount; i++) {
            const orbitalIndex = state.pointOrbitalIndices[i] || 0;
            if (!orbitalPointGroups[orbitalIndex]) {
                orbitalPointGroups[orbitalIndex] = [];
            }
            orbitalPointGroups[orbitalIndex].push(i);
        }

        // 每组内部排序
        for (const groupKey of Object.keys(orbitalPointGroups)) {
            const groupIndices = orbitalPointGroups[groupKey];
            groupIndices.sort((a, b) => state.contourDensities[b] - state.contourDensities[a]);

            const groupSize = groupIndices.length;
            for (let rank = 0; rank < groupSize; rank++) {
                const pointIndex = groupIndices[rank];
                state.contourRanks[pointIndex] = rank / (groupSize - 1 || 1);
            }
        }
    } else {
        // 所有点一起排序
        const indices = new Array(pointCount);
        for (let i = 0; i < pointCount; i++) indices[i] = i;
        indices.sort((a, b) => state.contourDensities[b] - state.contourDensities[a]);

        for (let rank = 0; rank < pointCount; rank++) {
            const pointIndex = indices[rank];
            state.contourRanks[pointIndex] = rank / (pointCount - 1 || 1);
        }
    }

    console.log('[Contour] 密度排名计算完成，应用高亮效果...');

    // 应用等值面高亮效果
    window.ElectronCloud.Visualization.updateContourHighlight();
};

/**
 * 更新等值面高亮效果
 * 高亮排名在95%附近的点，并程序化插入更多点增加密度
 */
window.ElectronCloud.Visualization.updateContourHighlight = function () {
    const state = window.ElectronCloud.state;

    if (!state.contourHighlightEnabled || !state.points || !state.contourRanks) {
        return;
    }

    const colors = state.points.geometry.attributes.color;
    const positions = state.points.geometry.attributes.position;
    const pointCount = state.pointCount;
    const colorArray = colors.array;
    const posArray = positions.array;

    // 等值面位置：95%分位（rank = 0.95）
    const contourPosition = 0.95;
    // 等值面宽度：控制高亮区域的粗细（缩小到1%）
    const contourWidth = 0.01;

    // 高亮颜色（亮绿色）
    const highlightR = 0.3;
    const highlightG = 1.0;
    const highlightB = 0.6;

    // 收集等值面附近的点用于后续插点
    const contourPoints = [];

    for (let i = 0; i < pointCount; i++) {
        const i3 = i * 3;
        const rank = state.contourRanks[i];

        // 计算距离等值面的距离
        const distToContour = Math.abs(rank - contourPosition);

        if (distToContour < contourWidth) {
            // 在等值面附近：高亮显示
            // 使用更高的亮度（3.0-5.0）
            const intensity = 1.0 - (distToContour / contourWidth);
            const brightness = 3.0 + intensity * 2.0;

            colorArray[i3] = Math.min(1.0, highlightR * brightness);
            colorArray[i3 + 1] = Math.min(1.0, highlightG * brightness);
            colorArray[i3 + 2] = Math.min(1.0, highlightB * brightness);

            // 记录等值面点位置
            contourPoints.push({
                x: posArray[i3],
                y: posArray[i3 + 1],
                z: posArray[i3 + 2],
                psiSign: state.contourPsiSigns[i]
            });
        } else {
            // 远离等值面：显示为非常暗（几乎透明）
            const dimFactor = 0.05;
            colorArray[i3] = state.contourBaseColors[i3] * dimFactor;
            colorArray[i3 + 1] = state.contourBaseColors[i3 + 1] * dimFactor;
            colorArray[i3 + 2] = state.contourBaseColors[i3 + 2] * dimFactor;
        }
    }

    colors.needsUpdate = true;

    console.log('[Contour] 等值面点数:', contourPoints.length);

    // 程序化插入更多点（在等值面点之间插值）
    if (contourPoints.length > 100) {
        window.ElectronCloud.Visualization.createContourInterpolationPoints(contourPoints);
    }

    console.log('[Contour] 高亮效果已应用');
};

/**
 * 程序化生成等值面点（使用波函数直接计算）
 * 在球面上均匀采样方向，用二分搜索找到等值面半径，生成均匀分布的点
 */
window.ElectronCloud.Visualization.createContourInterpolationPoints = function (contourPoints) {
    const state = window.ElectronCloud.state;
    const ui = window.ElectronCloud.ui;
    const Hydrogen = window.Hydrogen;

    // 移除旧的插值点
    if (state.contourInterpolationPoints) {
        state.scene.remove(state.contourInterpolationPoints);
        state.contourInterpolationPoints.geometry.dispose();
        state.contourInterpolationPoints.material.dispose();
        state.contourInterpolationPoints = null;
    }

    // 获取轨道参数
    const isHybridMode = state.isHybridMode === true;
    const orbitals = state.currentOrbitals || [state.currentOrbital || '1s'];
    let orbitalParams = orbitals.map(key => Hydrogen.orbitalParamsFromKey(key)).filter(Boolean);

    if (isHybridMode && Hydrogen.sortOrbitalsForHybridization) {
        orbitalParams = Hydrogen.sortOrbitalsForHybridization(orbitalParams);
    }

    if (orbitalParams.length === 0) return;

    // 获取杂化系数
    let coeffMatrix = null;
    if (isHybridMode && Hydrogen.getHybridCoefficients && orbitalParams.length > 1) {
        coeffMatrix = Hydrogen.getHybridCoefficients(orbitalParams.length);
    }

    // 计算波函数值
    const calcPsi = (r, theta, phi) => {
        if (isHybridMode && coeffMatrix) {
            // 杂化模式：取所有杂化轨道中绝对值最大的波函数
            let maxAbsPsi = 0;
            let dominantPsi = 0;
            for (let h = 0; h < orbitalParams.length; h++) {
                const coeffs = coeffMatrix[h];
                let psi = 0;
                for (let j = 0; j < orbitalParams.length; j++) {
                    const op = orbitalParams[j];
                    const R = Hydrogen.radialWavefunction(op.n, op.l, r);
                    const Y = Hydrogen.realYlm_value(op.angKey.l, op.angKey.m, op.angKey.t, theta, phi);
                    psi += coeffs[j] * R * Y;
                }
                if (Math.abs(psi) > maxAbsPsi) {
                    maxAbsPsi = Math.abs(psi);
                    dominantPsi = psi;
                }
            }
            return dominantPsi;
        } else {
            // 单选或多选模式
            let psi = 0;
            for (const op of orbitalParams) {
                const R = Hydrogen.radialWavefunction(op.n, op.l, r);
                const Y = Hydrogen.realYlm_value(op.angKey.l, op.angKey.m, op.angKey.t, theta, phi);
                psi += R * Y;
            }
            return psi;
        }
    };

    // 计算密度
    const calcDensity = (r, theta, phi) => {
        const psi = calcPsi(r, theta, phi);
        return psi * psi;
    };

    // 从现有采样点估算95%密度阈值
    const sortedDensities = [...state.contourDensities.slice(0, state.pointCount)].sort((a, b) => b - a);
    const index95 = Math.floor(sortedDensities.length * 0.95);
    const densityThreshold = sortedDensities[index95] || 0;

    // 估算平均半径
    const positions = state.points.geometry.attributes.position.array;
    let sumR = 0;
    for (let i = 0; i < state.pointCount; i++) {
        const i3 = i * 3;
        const x = positions[i3];
        const y = positions[i3 + 1];
        const z = positions[i3 + 2];
        sumR += Math.sqrt(x * x + y * y + z * z);
    }
    const avgRadius = sumR / state.pointCount;

    console.log('[Contour] 密度阈值:', densityThreshold, '平均半径:', avgRadius);

    // 在球面上均匀采样方向，生成等值面点
    const interpolatedPositions = [];
    const interpolatedColors = [];

    // 高亮颜色
    const highlightR = 0.3;
    const highlightG = 1.0;
    const highlightB = 0.6;
    const brightness = 4.0;

    // 使用黄金螺旋在球面上均匀分布点
    const numPoints = 30000; // 生成30000个均匀分布的方向
    const goldenAngle = Math.PI * (3 - Math.sqrt(5)); // 黄金角

    for (let i = 0; i < numPoints; i++) {
        // 均匀分布的 y 坐标 (-1 到 1)
        const y = 1 - (i / (numPoints - 1)) * 2;
        const radiusFactor = Math.sqrt(1 - y * y);

        // 均匀分布的 phi 角度
        const phi = goldenAngle * i;

        // 转换为球坐标的 theta（极角，从 z 轴测量）
        const theta = Math.acos(Math.max(-1, Math.min(1, y)));

        // 在这个方向上用二分搜索找等值面半径
        let rMin = 0.1;
        let rMax = avgRadius * 2.5;

        // 检查 rMax 处的密度是否足够低
        const densityAtMax = calcDensity(rMax, theta, phi);
        if (densityAtMax > densityThreshold) {
            rMax = avgRadius * 3.5;
        }

        // 二分搜索找等值面
        let radius95 = avgRadius;
        for (let iter = 0; iter < 20; iter++) {
            const rMid = (rMin + rMax) / 2;
            const density = calcDensity(rMid, theta, phi);

            if (density > densityThreshold) {
                rMin = rMid;
            } else {
                rMax = rMid;
            }
            radius95 = (rMin + rMax) / 2;
        }

        // 检查该方向的波函数相位
        const psi = calcPsi(radius95, theta, phi);

        // 只在有有效波函数的区域生成点（排除节面附近）
        if (Math.abs(psi) > densityThreshold * 0.1 && radius95 > 0.5) {
            // 转换为笛卡尔坐标
            const x = radius95 * Math.sin(theta) * Math.cos(phi);
            const yPos = radius95 * Math.cos(theta);
            const z = radius95 * Math.sin(theta) * Math.sin(phi);

            interpolatedPositions.push(x, yPos, z);
            interpolatedColors.push(
                Math.min(1.0, highlightR * brightness),
                Math.min(1.0, highlightG * brightness),
                Math.min(1.0, highlightB * brightness)
            );
        }
    }

    console.log('[Contour] 使用波函数生成等值面点:', interpolatedPositions.length / 3);

    if (interpolatedPositions.length === 0) return;

    // 创建点云几何体
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(interpolatedPositions, 3));
    geometry.setAttribute('color', new THREE.Float32BufferAttribute(interpolatedColors, 3));

    // 使用与原始点云相同的材质
    const sprite = window.ElectronCloud.Scene.generateCircleSprite();
    const material = new THREE.PointsMaterial({
        map: sprite,
        size: state.points.material.size * 1.2,
        vertexColors: true,
        transparent: true,
        opacity: 1.0,
        depthWrite: false,
        blending: THREE.AdditiveBlending
    });

    state.contourInterpolationPoints = new THREE.Points(geometry, material);
    state.contourInterpolationPoints.layers.set(0);
    state.scene.add(state.contourInterpolationPoints);

    console.log('[Contour] 等值面点已添加到场景');
};

/**
 * 禁用等值面轮廓高亮
 * 恢复原始点云颜色，并移除插值点
 */
window.ElectronCloud.Visualization.disableContourHighlight = function () {
    const state = window.ElectronCloud.state;

    // 移除插值点
    if (state.contourInterpolationPoints) {
        state.scene.remove(state.contourInterpolationPoints);
        state.contourInterpolationPoints.geometry.dispose();
        state.contourInterpolationPoints.material.dispose();
        state.contourInterpolationPoints = null;
        console.log('[Contour] 已移除插值点');
    }

    if (!state.points || !state.contourBaseColors) {
        state.contourHighlightEnabled = false;
        return;
    }

    state.contourHighlightEnabled = false;

    // 恢复原始颜色
    const colors = state.points.geometry.attributes.color;
    const pointCount = state.pointCount;
    const colorArray = colors.array;

    for (let i = 0; i < pointCount * 3; i++) {
        colorArray[i] = state.contourBaseColors[i];
    }

    colors.needsUpdate = true;
    console.log('[Contour] 已恢复原始颜色');
};

// ==================== 网格等值面 ====================

window.ElectronCloud.Visualization.createContourOverlay = function () {
    const state = window.ElectronCloud.state;
    const overlayGroup = new THREE.Group();

    if (!state.points || state.pointCount < 100) {
        return overlayGroup;
    }

    const contourRadius = window.ElectronCloud.Visualization.calculate95PercentileRadius();

    if (contourRadius <= 0) {
        return overlayGroup;
    }

    window.ElectronCloud.Visualization.createContourMesh(overlayGroup, contourRadius);
    return overlayGroup;
};

window.ElectronCloud.Visualization.calculate95PercentileRadius = function () {
    const state = window.ElectronCloud.state;
    if (!state.radialSamples || state.radialSamples.length < 100) {
        return state.farthestDistance * 0.8;
    }
    const sortedRadii = state.radialSamples.slice(0, state.pointCount).sort((a, b) => a - b);
    const index95 = Math.floor(sortedRadii.length * 0.95);
    return sortedRadii[index95];
};

window.ElectronCloud.Visualization.calculate95PercentileRadiusMap = function (thetaBins = 32, phiBins = 64) {
    const state = window.ElectronCloud.state;
    const radiusBins = new Array(thetaBins).fill(null).map(() =>
        new Array(phiBins).fill(null).map(() => [])
    );

    if (!state.points || !state.points.geometry) {
        return null;
    }

    const positions = state.points.geometry.attributes.position.array;

    for (let i = 0; i < state.pointCount; i++) {
        const i3 = i * 3;
        const x = positions[i3];
        const y = positions[i3 + 1];
        const z = positions[i3 + 2];
        const r = Math.sqrt(x * x + y * y + z * z);
        if (r < 1e-10) continue;
        const theta = Math.acos(z / r);
        const phi = Math.atan2(y, x);
        const thetaIndex = Math.min(thetaBins - 1, Math.floor((theta / Math.PI) * thetaBins));
        const phiIndex = Math.min(phiBins - 1, Math.floor(((phi + Math.PI) / (2 * Math.PI)) * phiBins));
        radiusBins[thetaIndex][phiIndex].push(r);
    }

    const radiusMap = new Array(thetaBins).fill(0).map(() => new Array(phiBins).fill(0));
    let globalMax = 0;

    for (let i = 0; i < thetaBins; i++) {
        for (let j = 0; j < phiBins; j++) {
            const samples = radiusBins[i][j];
            if (samples.length < 5) {
                radiusMap[i][j] = -1;
            } else {
                samples.sort((a, b) => a - b);
                const index95 = Math.floor(samples.length * 0.95);
                radiusMap[i][j] = samples[index95];
                globalMax = Math.max(globalMax, samples[index95]);
            }
        }
    }

    for (let i = 0; i < thetaBins; i++) {
        for (let j = 0; j < phiBins; j++) {
            if (radiusMap[i][j] < 0) {
                let sum = 0, count = 0;
                for (let di = -2; di <= 2; di++) {
                    for (let dj = -2; dj <= 2; dj++) {
                        const ni = (i + di + thetaBins) % thetaBins;
                        const nj = (j + dj + phiBins) % phiBins;
                        if (radiusMap[ni][nj] > 0) {
                            sum += radiusMap[ni][nj];
                            count++;
                        }
                    }
                }
                radiusMap[i][j] = count > 0 ? sum / count : globalMax * 0.8;
            }
        }
    }

    return { radiusMap, thetaBins, phiBins, globalMax };
};
/**
 * 创建等值面网格 - 基于 Marching Cubes 算法
 * 每个波瓣生成独立的封闭等值面，自动分离连通域
 */
// 更新点云相位颜色
window.ElectronCloud.Visualization.updatePointColors = function () {
    const state = window.ElectronCloud.state;
    if (!state.points) return;

    const positions = state.points.geometry.attributes.position.array;
    const colors = state.points.geometry.attributes.color.array;
    const pointCount = state.pointCount;

    // 预备参数
    const isHybridMode = state.isHybridMode === true;
    const orbitals = state.currentOrbitals || [];
    let orbitalParams = orbitals.map(key => Hydrogen.orbitalParamsFromKey(key)).filter(Boolean);

    if (orbitalParams.length === 0) return;

    if (isHybridMode && Hydrogen.sortOrbitalsForHybridization) {
        orbitalParams = Hydrogen.sortOrbitalsForHybridization(orbitalParams);
    }

    let coeffMatrix = null;
    if (isHybridMode && orbitalParams.length > 1 && Hydrogen.getHybridCoefficients) {
        coeffMatrix = Hydrogen.getHybridCoefficients(orbitalParams.length);
    }

    // 颜色定义（注意：此处颜色与采样时相反，以保证后开相位显示一致性）
    const colorPos = { r: 1.0, g: 0.0, b: 0.0 }; // psi>=0 用红
    const colorNeg = { r: 0.0, g: 0.0, b: 1.0 }; // psi<0 用蓝
    const colorWhite = { r: 1.0, g: 1.0, b: 1.0 };

    // 遍历所有点
    for (let i = 0; i < pointCount; i++) {
        const i3 = i * 3;
        const x = positions[i3];
        const y = positions[i3 + 1];
        const z = positions[i3 + 2];

        // 默认白色 (未开启相位显示时)
        if (!state.usePhaseColoring) {
            colors[i3] = colorWhite.r;
            colors[i3 + 1] = colorWhite.g;
            colors[i3 + 2] = colorWhite.b;
            continue;
        }

        // 计算 Psi (复用 createContourMesh 的逻辑)
        let psi = 0;
        const r = Math.sqrt(x * x + y * y + z * z);
        if (r < 1e-10) {
            psi = 0;
        } else {
            const theta = Math.acos(Math.max(-1, Math.min(1, z / r)));
            const phi = Math.atan2(y, x);

            if (isHybridMode && coeffMatrix) {
                let maxAbsPsi = 0;
                for (let h = 0; h < orbitalParams.length; h++) {
                    let hPsi = 0;
                    for (let k = 0; k < orbitalParams.length; k++) {
                        const op = orbitalParams[k];
                        hPsi += coeffMatrix[h][k] * Hydrogen.radialWavefunction(op.n, op.l, r) *
                            Hydrogen.realYlm_value(op.angKey.l, op.angKey.m, op.angKey.t, theta, phi);
                    }
                    if (Math.abs(hPsi) > maxAbsPsi) {
                        maxAbsPsi = Math.abs(hPsi);
                        psi = hPsi;
                    }
                }
            } else {
                // 单轨/多轨叠加
                // 如果是多轨模式，点云中的点实际上属于特定轨道
                // 但为了相位显示的连续性，我们可以计算叠加场的相位，或者区分轨道
                // 这里采用：计算叠加波函数 psi (简单叠加)
                for (const op of orbitalParams) {
                    psi += Hydrogen.radialWavefunction(op.n, op.l, r) *
                        Hydrogen.realYlm_value(op.angKey.l, op.angKey.m, op.angKey.t, theta, phi);
                }
            }
        }

        // 根据相位上色
        if (psi >= 0) {
            colors[i3] = colorPos.r;
            colors[i3 + 1] = colorPos.g;
            colors[i3 + 2] = colorPos.b;
        } else {
            colors[i3] = colorNeg.r;
            colors[i3 + 1] = colorNeg.g;
            colors[i3 + 2] = colorNeg.b;
        }
    }

    state.points.geometry.attributes.color.needsUpdate = true;
};

window.ElectronCloud.Visualization.createContourMesh = function (group, baseRadius) {
    console.log('[Contour] Marching Cubes, baseRadius:', baseRadius);

    const state = window.ElectronCloud.state;
    const isHybridMode = state.isHybridMode === true;

    const orbitals = state.currentOrbitals || [];
    let orbitalParams = orbitals.map(key => Hydrogen.orbitalParamsFromKey(key)).filter(Boolean);
    if (orbitalParams.length === 0) return;

    if (isHybridMode && Hydrogen.sortOrbitalsForHybridization) {
        orbitalParams = Hydrogen.sortOrbitalsForHybridization(orbitalParams);
    }

    let coeffMatrix = null;
    if (isHybridMode && orbitalParams.length > 1 && Hydrogen.getHybridCoefficients) {
        coeffMatrix = Hydrogen.getHybridCoefficients(orbitalParams.length);
    }

    // 波函数计算 (直角坐标)
    function calcPsi(x, y, z) {
        const r = Math.sqrt(x * x + y * y + z * z);
        if (r < 1e-10) return 0;
        const theta = Math.acos(Math.max(-1, Math.min(1, z / r)));
        const phi = Math.atan2(y, x);

        if (isHybridMode && coeffMatrix) {
            let maxAbsPsi = 0, dominantPsi = 0;
            for (let h = 0; h < orbitalParams.length; h++) {
                let psi = 0;
                for (let i = 0; i < orbitalParams.length; i++) {
                    const op = orbitalParams[i];
                    psi += coeffMatrix[h][i] * Hydrogen.radialWavefunction(op.n, op.l, r) *
                        Hydrogen.realYlm_value(op.angKey.l, op.angKey.m, op.angKey.t, theta, phi);
                }
                if (Math.abs(psi) > maxAbsPsi) { maxAbsPsi = Math.abs(psi); dominantPsi = psi; }
            }
            return dominantPsi;
        } else {
            let psi = 0;
            for (const op of orbitalParams) {
                psi += Hydrogen.radialWavefunction(op.n, op.l, r) *
                    Hydrogen.realYlm_value(op.angKey.l, op.angKey.m, op.angKey.t, theta, phi);
            }
            return psi;
        }
    }

    // 计算等值面阈值
    // 使用 95% 分位的 |ψ| 作为边界（即包含 95% 概率的等值面）
    const psiValues = [];
    const positions = state.points.geometry.attributes.position.array;
    for (let i = 0; i < state.pointCount; i++) {
        const i3 = i * 3;
        psiValues.push(Math.abs(calcPsi(positions[i3], positions[i3 + 1], positions[i3 + 2])));
    }
    psiValues.sort((a, b) => a - b);
    const isovalue = psiValues[Math.floor(psiValues.length * 0.05)] || 0.0001;
    console.log('[Contour] isovalue:', isovalue.toFixed(8));

    // Marching Cubes - 优化分辨率以兼顾性能和质量
    const bound = baseRadius * 1.3;
    const resolution = 120; // 提升分辨率至 120
    const result = window.MarchingCubes.run(calcPsi, { min: [-bound, -bound, -bound], max: [bound, bound, bound] }, resolution, isovalue);

    console.log('[Contour] 正波瓣:', result.positive.length / 3, '三角形, 负波瓣:', result.negative.length / 3, '三角形');

    // 创建网格
    function addLobeMeshes(triangles, color) {
        if (triangles.length < 9) return;
        const components = window.MarchingCubes.separate(triangles);
        console.log('[Contour] 分离出', components.length, '个连通域');

        for (const comp of components) {
            if (comp.length < 9) continue;
            const geom = window.MarchingCubes.toGeometry(comp);
            const colors = new Float32Array(comp.length * 3);
            for (let i = 0; i < comp.length; i++) { colors[i * 3] = color.r; colors[i * 3 + 1] = color.g; colors[i * 3 + 2] = color.b; }
            geom.setAttribute('color', new THREE.BufferAttribute(colors, 3));

            const mesh = new THREE.Mesh(geom, new THREE.MeshBasicMaterial({
                vertexColors: true, transparent: true, opacity: 0.55,
                side: THREE.DoubleSide, wireframe: true, wireframeLinewidth: 1.5
            }));
            mesh.layers.set(1);
            group.add(mesh);
        }
    }

    const standardColor = { r: 0.2, g: 1.0, b: 0.5 }; // 默认绿色
    const colorPos = { r: 0.0, g: 0.75, b: 1.0 };     // 冰蓝
    const colorNeg = { r: 1.0, g: 0.27, b: 0.0 };     // 橙色

    if (state.usePhaseColoring) {
        // 开启相位显示：正蓝负红
        addLobeMeshes(result.positive, colorPos);
        addLobeMeshes(result.negative, colorNeg);
    } else {
        // 关闭相位显示：统一绿色 (默认)
        addLobeMeshes(result.positive, standardColor);
        addLobeMeshes(result.negative, standardColor);
    }
};

window.ElectronCloud.Visualization.createContourOverlay = function () {
    const state = window.ElectronCloud.state;
    const group = new THREE.Group();

    if (!state.points) return group;

    // 计算包围球半径
    const positions = state.points.geometry.attributes.position.array;
    let maxR = 0;
    for (let i = 0; i < state.pointCount; i++) {
        const x = positions[i * 3];
        const y = positions[i * 3 + 1];
        const z = positions[i * 3 + 2];
        const r = Math.sqrt(x * x + y * y + z * z);
        if (r > maxR) maxR = r;
    }
    const baseRadius = maxR > 0 ? maxR : 10;

    // 创建 Marching Cubes 等值面
    window.ElectronCloud.Visualization.createContourMesh(group, baseRadius);

    return group;
};

window.ElectronCloud.Visualization.updateContourOverlay = function () {
    const state = window.ElectronCloud.state;
    const ui = window.ElectronCloud.ui;

    const toggle = document.getElementById('contour-3d-toggle');
    if (!toggle || !toggle.checked) {
        if (state.contourOverlay) {
            state.scene.remove(state.contourOverlay);
            state.contourOverlay.traverse((child) => {
                if (child.geometry) child.geometry.dispose();
                if (child.material) child.material.dispose();
            });
            state.contourOverlay = null;
        }
        return;
    }

    if (state.contourOverlay) {
        state.scene.remove(state.contourOverlay);
        state.contourOverlay.traverse((child) => {
            if (child.geometry) child.geometry.dispose();
            if (child.material) child.material.dispose();
        });
    }

    state.contourOverlay = window.ElectronCloud.Visualization.createContourOverlay();
    state.contourOverlay.visible = true;

    if (state.points) {
        state.contourOverlay.rotation.copy(state.points.rotation);
        state.contourOverlay.updateMatrix();
    }

    state.scene.add(state.contourOverlay);
};

/**
 * 创建杂化轨道的独立等值面轮廓（每个轨道一个）
 * 只为可见的轨道创建等值面
 */
window.ElectronCloud.Visualization.createHybridContourOverlays = function () {
    const state = window.ElectronCloud.state;
    const overlays = [];

    if (!state.isHybridMode || !state.hybridOrbitalPointsMap) {
        return overlays;
    }

    const orbitals = state.currentOrbitals || [];
    let orbitalParams = orbitals.map(key => Hydrogen.orbitalParamsFromKey(key)).filter(Boolean);

    if (orbitalParams.length === 0) return overlays;

    // 对轨道进行排序
    if (Hydrogen.sortOrbitalsForHybridization) {
        orbitalParams = Hydrogen.sortOrbitalsForHybridization(orbitalParams);
    }

    const numOrbitals = orbitalParams.length;
    const coeffMatrix = Hydrogen.getHybridCoefficients ? Hydrogen.getHybridCoefficients(numOrbitals) : null;

    if (!coeffMatrix) return overlays;

    // 不同颜色用于区分各个杂化轨道
    const colors = [
        { r: 0.2, g: 1.0, b: 0.5 },   // 绿色
        { r: 1.0, g: 0.5, b: 0.2 },   // 橙色
        { r: 0.2, g: 0.5, b: 1.0 },   // 蓝色
        { r: 1.0, g: 0.2, b: 0.8 },   // 粉色
        { r: 0.8, g: 1.0, b: 0.2 },   // 黄绿色
        { r: 0.2, g: 1.0, b: 1.0 },   // 青色
    ];

    // 为每个可见的杂化轨道创建等值面
    for (let hybridIndex = 0; hybridIndex < numOrbitals; hybridIndex++) {
        // 检查该轨道是否可见
        if (state.hybridOrbitalVisibility && state.hybridOrbitalVisibility[hybridIndex] === false) {
            overlays.push(null); // 占位，保持索引一致
            continue;
        }

        const pointIndices = state.hybridOrbitalPointsMap[hybridIndex] || [];
        if (pointIndices.length < 50) {
            overlays.push(null);
            continue;
        }

        const overlay = createSingleHybridContour(
            orbitalParams,
            coeffMatrix[hybridIndex],
            hybridIndex,
            pointIndices,
            colors[hybridIndex % colors.length]
        );

        if (overlay) {
            overlays.push(overlay);
        } else {
            overlays.push(null);
        }
    }

    return overlays;

    // 内部函数：创建单个杂化轨道的等值面
    function createSingleHybridContour(orbitalParams, coeffs, hybridIndex, pointIndices, color) {
        const overlayGroup = new THREE.Group();

        // 波函数计算
        function calcPsi(x, y, z) {
            const r = Math.sqrt(x * x + y * y + z * z);
            if (r < 1e-10) return 0;
            const theta = Math.acos(Math.max(-1, Math.min(1, z / r)));
            const phi = Math.atan2(y, x);

            let psi = 0;
            for (let j = 0; j < orbitalParams.length; j++) {
                const op = orbitalParams[j];
                const R = Hydrogen.radialWavefunction(op.n, op.l, r);
                const Y = Hydrogen.realYlm_value(op.angKey.l, op.angKey.m, op.angKey.t, theta, phi);
                psi += coeffs[j] * R * Y;
            }
            return psi;
        }

        // 计算该轨道点的95%分位密度阈值
        const positions = state.points.geometry.attributes.position.array;
        const psiValues = [];
        let maxR = 0;

        for (const pointIdx of pointIndices) {
            const i3 = pointIdx * 3;
            const x = positions[i3];
            const y = positions[i3 + 1];
            const z = positions[i3 + 2];
            const r = Math.sqrt(x * x + y * y + z * z);
            if (r > maxR) maxR = r;

            // 计算此处的 psi
            psiValues.push(Math.abs(calcPsi(x, y, z)));
        }

        if (psiValues.length < 50) return null;

        psiValues.sort((a, b) => a - b);
        // 95% 概率包含在等值面内 = 5% 的点在外面 (小值)
        const isovalue = psiValues[Math.floor(psiValues.length * 0.05)] || 0.0001;

        // Marching Cubes
        // 边界：使用最大点半径再扩大一点
        const bound = (maxR > 0 ? maxR : 10) * 1.3;
        const resolution = 120; // 提升分辨率至 120

        const result = window.MarchingCubes.run(calcPsi, { min: [-bound, -bound, -bound], max: [bound, bound, bound] }, resolution, isovalue);

        // 添加网格
        // 添加网格
        function addLobeMeshes(triangles, meshColor) {
            if (triangles.length < 9) return;
            const components = window.MarchingCubes.separate(triangles);

            for (const comp of components) {
                if (comp.length < 9) continue;
                const geom = window.MarchingCubes.toGeometry(comp);
                const colors = new Float32Array(comp.length * 3);
                for (let i = 0; i < comp.length; i++) {
                    colors[i * 3] = meshColor.r;
                    colors[i * 3 + 1] = meshColor.g;
                    colors[i * 3 + 2] = meshColor.b;
                }
                geom.setAttribute('color', new THREE.BufferAttribute(colors, 3));

                const mesh = new THREE.Mesh(geom, new THREE.MeshBasicMaterial({
                    vertexColors: true, transparent: true, opacity: 0.6,
                    side: THREE.DoubleSide, wireframe: true, wireframeLinewidth: 1.0
                }));
                mesh.layers.set(1);
                overlayGroup.add(mesh);
            }
        }

        // 杂化轨道颜色逻辑
        if (state.usePhaseColoring) {
            const colorPos = { r: 0.0, g: 0.75, b: 1.0 }; // 冰蓝
            const colorNeg = { r: 1.0, g: 0.27, b: 0.0 }; // 橙色
            addLobeMeshes(result.positive, colorPos);
            addLobeMeshes(result.negative, colorNeg);
        } else {
            // 默认显示区分颜色
            addLobeMeshes(result.positive, color);
            addLobeMeshes(result.negative, color);
        }

        if (overlayGroup.children.length > 0) {
            return overlayGroup;
        }
        return null;
    }
};

/**
 * 创建高密度测地线球体网格 (Icosphere)
 * 手动细分二十面体，绕过 Three.js 版本限制
 * @param { number } radius 半径
 * @param { number } detail 细分等级(建议 5 或 6)
 */
window.ElectronCloud.Visualization.createGeodesicIcosphere = function (radius, detail) {
    const t = (1 + Math.sqrt(5)) / 2;
    const vertices = [
        -1, t, 0, 1, t, 0, -1, -t, 0, 1, -t, 0,
        0, -1, t, 0, 1, t, 0, -1, -t, 0, 1, -t,
        t, 0, -1, t, 0, 1, -t, 0, -1, -t, 0, 1
    ];
    const indices = [
        0, 11, 5, 0, 5, 1, 0, 1, 7, 0, 7, 10, 0, 10, 11,
        1, 5, 9, 5, 11, 4, 11, 10, 2, 10, 7, 6, 7, 1, 8,
        3, 9, 4, 3, 4, 2, 3, 2, 6, 3, 6, 8, 3, 8, 9,
        4, 9, 5, 2, 4, 11, 6, 2, 10, 8, 6, 7, 9, 8, 1
    ];

    let faces = [];
    for (let i = 0; i < indices.length; i += 3) {
        faces.push([
            new THREE.Vector3(vertices[indices[i] * 3], vertices[indices[i] * 3 + 1], vertices[indices[i] * 3 + 2]).normalize().multiplyScalar(radius),
            new THREE.Vector3(vertices[indices[i + 1] * 3], vertices[indices[i + 1] * 3 + 1], vertices[indices[i + 1] * 3 + 2]).normalize().multiplyScalar(radius),
            new THREE.Vector3(vertices[indices[i + 2] * 3], vertices[indices[i + 2] * 3 + 1], vertices[indices[i + 2] * 3 + 2]).normalize().multiplyScalar(radius)
        ]);
    }

    for (let d = 0; d < detail; d++) {
        const newFaces = [];
        for (const tri of faces) {
            const v1 = tri[0];
            const v2 = tri[1];
            const v3 = tri[2];
            const a = v1.clone().add(v2).multiplyScalar(0.5).normalize().multiplyScalar(radius);
            const b = v2.clone().add(v3).multiplyScalar(0.5).normalize().multiplyScalar(radius);
            const c = v3.clone().add(v1).multiplyScalar(0.5).normalize().multiplyScalar(radius);

            newFaces.push([v1, a, c]);
            newFaces.push([v2, b, a]);
            newFaces.push([v3, c, b]);
            newFaces.push([a, b, c]);
        }
        faces = newFaces;
    }

    const positions = new Float32Array(faces.length * 9);
    for (let i = 0; i < faces.length; i++) {
        positions[i * 9] = faces[i][0].x;
        positions[i * 9 + 1] = faces[i][0].y;
        positions[i * 9 + 2] = faces[i][0].z;
        positions[i * 9 + 3] = faces[i][1].x;
        positions[i * 9 + 4] = faces[i][1].y;
        positions[i * 9 + 5] = faces[i][1].z;
        positions[i * 9 + 6] = faces[i][2].x;
        positions[i * 9 + 7] = faces[i][2].y;
        positions[i * 9 + 8] = faces[i][2].z;
    }

    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    return geometry;
};

